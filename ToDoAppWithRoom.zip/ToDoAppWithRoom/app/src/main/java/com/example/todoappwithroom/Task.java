package com.example.todoappwithroom;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Task {
    private String title;
    private String description;
    private boolean isCompleted;

    // Геттеры и сеттеры для title, description, и isCompleted
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        this.isCompleted = completed;
    }
}

