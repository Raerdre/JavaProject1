package com.example.todoappwithroom;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.concurrent.Executors;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private List<Task> tasks;
    private TaskDao taskDao;

    public TaskAdapter(List<Task> tasks, TaskDao taskDao) {
        this.tasks = tasks;
        this.taskDao = taskDao;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = tasks.get(position);
        holder.textViewTitle.setText(task.getTitle());  // Устанавливает название задачи
        holder.textViewTaskDescription.setText(task.getDescription());
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
        notifyDataSetChanged();
    }

    class TaskViewHolder extends RecyclerView.ViewHolder {

        public ViewStructure textViewTaskDescription;
        private TextView textViewTitle;
        private CheckBox checkBoxCompleted;
        private Button buttonDelete;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textView_task_title);
            checkBoxCompleted = itemView.findViewById(R.id.checkBox_completed);
            buttonDelete = itemView.findViewById(R.id.button_delete);
        }

        public void bind(Task task) {
            textViewTitle.setText(task.getTitle());
            checkBoxCompleted.setChecked(task.isCompleted());

            // Обработка нажатия на CheckBox для обновления состояния задачи
            checkBoxCompleted.setOnCheckedChangeListener((buttonView, isChecked) -> {
                task.setCompleted(isChecked);
                Executors.newSingleThreadExecutor().execute(() -> {
                    taskDao.update(task); // Обновление задачи в базе данных
                });
            });

            // Обработка кнопки удаления
            buttonDelete.setOnClickListener(v -> {
                Executors.newSingleThreadExecutor().execute(() -> {
                    taskDao.delete(task); // Удаление задачи в базе данных
                    tasks.remove(getAdapterPosition());
                    // Обновление интерфейса на основном потоке
                    ((MainActivity) itemView.getContext()).runOnUiThread(() -> {
                        notifyItemRemoved(getAdapterPosition());
                    });
                });
            });
        }
    }
}
