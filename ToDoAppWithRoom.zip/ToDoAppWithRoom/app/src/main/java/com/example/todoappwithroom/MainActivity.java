package com.example.todoappwithroom;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TaskAdapter taskAdapter;
    private TaskDatabase taskDatabase;
    private RecyclerView recyclerView;
    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskDatabase = TaskDatabase.getInstance(this); // Инициализация базы данных

        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList, taskDatabase.taskDao()); // Инициализация адаптера с taskDao
        recyclerView.setAdapter(taskAdapter);

        loadTasks();

        FloatingActionButton fabAddTask = findViewById(R.id.fab_add_task);
        fabAddTask.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
            startActivity(intent);
        });
    }

    private void loadTasks() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Task> tasks = taskDatabase.taskDao().getAllTasks();
            runOnUiThread(() -> {
                taskAdapter.setTasks(tasks); // Обновляем данные адаптера
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasks();
    }
}
