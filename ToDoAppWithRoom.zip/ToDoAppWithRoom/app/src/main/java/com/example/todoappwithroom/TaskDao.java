package com.example.todoappwithroom;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface TaskDao {
    @Insert
    void insert(Task task);

    @Query("SELECT * FROM task_table")
    List<Task> getAllTasks();
	
	@Delete
    void delete(Task task); // Метод для удаления задачи

    @Update
    void update(Task task); // Метод для обновления задачи
}
