package com.example.todoappwithroom;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.Executors;


public class AddTaskActivity extends AppCompatActivity {

    private EditText editTextTitle;
    private EditText editTextDescription;
    private TaskDatabase taskDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        editTextTitle = findViewById(R.id.edit_text_title);
        editTextDescription = findViewById(R.id.edit_text_description);
        Button buttonSave = findViewById(R.id.button_save);

        taskDatabase = TaskDatabase.getInstance(this);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveTask();
            }
        });
    }

    private void saveTask() {
		String title = editTextTitle.getText().toString();
		String description = editTextDescription.getText().toString();

		if (TextUtils.isEmpty(title)) {
			Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show();
			return;
		}

		// Создаём новую задачу
		Task task = new Task(title, description);

		// Сохраняем задачу в базе данных в фоновом потоке
		Executors.newSingleThreadExecutor().execute(() -> {
			taskDatabase.taskDao().insert(task);

			// Переходим на главный экран с сообщением об успешном сохранении
			runOnUiThread(() -> {
				Toast.makeText(AddTaskActivity.this, "Task saved", Toast.LENGTH_SHORT).show();
				finish(); // Закрываем AddTaskActivity
			});
		});
}
}
